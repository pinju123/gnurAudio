// if libgrio has no sources, it doesn't get built correctly
#include <gruel/attributes.h>
static int gr_bug_work_around_6 __GR_ATTR_UNUSED;
