double qsimp (double (*func)(double),
	      double a, double b);

